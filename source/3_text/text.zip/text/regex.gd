extends Control

@onready var text : TextEdit = $TextEdit
@onready var result: TextEdit = $Result


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


func _on_pattern_text_submitted(pattern: String) -> void:
	var regex = RegEx.new()
	regex.compile(pattern)
	var results = regex.search_all(text.text)
	print('pattern: ', pattern)
	print(regex.get_group_count())
	result.text = ""
	for r in results.slice(0, 100):
		result.text += r.get_string() + "\n"
