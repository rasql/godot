@tool
extends Control

@onready var tree: Tree = $Tree
var path = "res://alice.txt"
var voices = DisplayServer.tts_get_voices_for_language("en")
var voice_id = voices[0]

var histogram

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var file = FileAccess.open(path, FileAccess.READ)
	
	if not file:
		print("Error: ", FileAccess.get_open_error())
		return

	var content = file.get_as_text()
	$TextEdit.text = content
	
	print("path: ", path)
	print("size: ", content.length())
	
	var begin = "[Illustration]"
	var i_begin = content.find(begin) + len(begin) + 4
	content = content.right(-i_begin)
		
	var end = "THE END"
	var i_end = content.find(end)
	content = content.left(i_end)
	
	content = content.remove_chars(",;:!?()[]‘’“”*_$0123456789#%=+")
	
	content = content.replace("\n", " ")
	content = content.replace("—", " ")
	content = content.replace(".", " ")
	content = content.replace("/", " ")
	content = content.replace("  ", " ")
	
	content = content.to_lower()
	var words = content.split(" ")
	print("words ", words.size())
	
	var vocab : Dictionary[String, int] = {}
	
	for word in words:
		if word not in vocab:
			vocab[word] = 1
		else:
			vocab[word] += 1
	print("vocabulary: ", vocab.size())
	vocab.erase("")
	vocab.sort()
	
	histogram = []
	for key in vocab:
		histogram.append([key, key.length(), vocab[key]])
		
	print(histogram)
	
	
	# setup the tree control
	var root = tree.create_item()
	tree.hide_root = true
	tree.columns = 3
	tree.column_titles_visible = true
	tree.set_column_title(0, "words")
	tree.set_column_title(1, "lenght")
	tree.set_column_title(2, "count")
	
	for word in vocab:
		var child = tree.create_item(root)
		child.set_text(0, word)
		child.set_text(1, str(word.length()))
		child.set_text(2, str(vocab[word]))
	

func _on_tree_cell_selected() -> void:
	var item = tree.get_selected()
	var column = tree.get_selected_column()
	var content = item.get_text(column)
	print(content)
	DisplayServer.tts_stop()
	DisplayServer.tts_speak(content, voice_id)
	
	


func _on_tree_column_title_clicked(column: int, mouse_button_index: int) -> void:
	print(column, " - ", mouse_button_index)
